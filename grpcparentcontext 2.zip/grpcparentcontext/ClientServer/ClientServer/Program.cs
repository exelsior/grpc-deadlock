using ClientServer;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Server;
using Server.Settings;

internal class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        // builder.WebHost.ConfigureKestrel(options =>
        // {
        //     var http2 = options.Limits.Http2;
        //     http2.InitialConnectionWindowSize = 1024 * 1024 * 16; // 16 MB
        //     http2.InitialStreamWindowSize = 1024 * 1024 * 16; // 16 MB
        // });

        var services = builder.Services;
        var configuration = builder.Configuration;
        services.Configure<KestrelServerOptions>(
            configuration.GetSection("Kestrel"));
        services.GetAndConfigureSettings<GrpcSettings>(configuration);

        services.AddGrpcReflection();
        services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

        services.AddGrpc(o =>
        {
            o.MaxReceiveMessageSize = null;
        });

        var app = builder.Build();

        app.MapGrpcService<GrpcService>()
            .WithDisplayName("gRPC");

        app.MapGrpcReflectionService();

        app.Run();
    }
}