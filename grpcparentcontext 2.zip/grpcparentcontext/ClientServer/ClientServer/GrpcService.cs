using ClientServerApp;
using Grpc.Core;
using Grpc.Net.Client;
using ServerApp;
using TestRequest = ClientServerApp.TestRequest;

namespace ClientServer;

public class GrpcService : GreeterClientService.GreeterClientServiceBase
{
    public GrpcService()
    {
    }

    public override async Task BiStreamTest(IAsyncStreamReader<TestRequest> requestStream, IServerStreamWriter<ClientServerApp.TestReply> responseStream, ServerCallContext context)
    {
        var channel = GrpcChannel.ForAddress("http://localhost:5126", new GrpcChannelOptions
        {
            UnsafeUseInsecureChannelCallCredentials = true,
            HttpHandler = new SocketsHttpHandler
            {
                EnableMultipleHttp2Connections = true,
                //InitialHttp2StreamWindowSize = 16777216
            },
            
        });
        var client = new Greeter.GreeterClient(channel);
        var metadata = new Metadata();
        var deadline = DateTime.UtcNow.AddMinutes(5);
        var call = client.BiStreamTest(metadata, deadline);
        await foreach(var item in requestStream.ReadAllAsync())
        {
            await call.RequestStream.WriteAsync(new ServerApp.TestRequest
            {
                Message = item.Message
            });
        }

        await call.RequestStream.CompleteAsync();
        
        while (await call.ResponseStream.MoveNext())
        {
            await responseStream.WriteAsync(new ClientServerApp.TestReply
            {
                Reply = call.ResponseStream.Current.Reply
            });
        }

        // await foreach (var response in call.ResponseStream.ReadAllAsync())
        // {
        //     await responseStream.WriteAsync(new ClientServerApp.TestReply
        //     {
        //         Reply = response.Reply
        //     });
        // }
    }
}