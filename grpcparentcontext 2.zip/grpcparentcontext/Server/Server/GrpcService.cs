using System.Xml;
using Grpc.Core;
using ServerApp;

namespace Server;

public class GrpcService : Greeter.GreeterBase
{
    public GrpcService()
    {
        
    }

    public override async Task BiStreamTest(IAsyncStreamReader<TestRequest> requestStream, IServerStreamWriter<TestReply> responseStream, ServerCallContext context)
    {
        // while (await requestStream.MoveNext())
        // {
        //     Console.WriteLine(requestStream.Current.Message);
        //     await Task.Delay(2000);
        //     await responseStream.WriteAsync(new TestReply
        //     {
        //         Reply = $"{requestStream.Current.Message}{requestStream.Current.Message}{requestStream.Current.Message}{requestStream.Current.Message}"
        //     });
        // }
        await foreach (var item in requestStream.ReadAllAsync())
        {
            Console.WriteLine(item.Message);
            await Task.Delay(2000);
            await responseStream.WriteAsync(new TestReply
            {
                Reply = $"{item.Message}{item.Message}{item.Message}{item.Message}"
            });
        }   
    }
}
    
    // using System.Xml;
    // using Grpc.Core;
    // using ServerApp;
    //
    // namespace Server;
    //
    // public class GrpcService : Greeter.GreeterBase
    // {
    //     public GrpcService()
    //     {
    //     
    //     }
    //
    //     public override async Task BiStreamTest(IAsyncStreamReader<TestRequest> requestStream, IServerStreamWriter<TestReply> responseStream, ServerCallContext context)
    //     {
    //         // while (await requestStream.MoveNext())
    //         // {
    //         //     Console.WriteLine(requestStream.Current.Message);
    //         //     await Task.Delay(2000);
    //         //     await responseStream.WriteAsync(new TestReply
    //         //     {
    //         //         Reply = $"{requestStream.Current.Message}{requestStream.Current.Message}{requestStream.Current.Message}{requestStream.Current.Message}"
    //         //     });
    //         // }
    //         var listRequests = new List<TestRequest>();
    //         await foreach (var item in requestStream.ReadAllAsync())
    //         {
    //             listRequests.Add(item);
    //         }
    //
    //         foreach (var request in listRequests)
    //         {
    //             Console.WriteLine(request.Message);
    //             await Task.Delay(2000);
    //             await responseStream.WriteAsync(new TestReply
    //             {
    //                 Reply = $"{request.Message}{request.Message}{request.Message}{request.Message}"
    //             });
    //         }
        // }