namespace Server.Settings;

public abstract class BaseSettings
{
    public abstract string ConfigBlockName { get; }
}