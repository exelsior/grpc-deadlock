namespace Server.Settings;

public class GrpcSettings : BaseSettings
{
    /// <summary>
    /// Таймаут выполнения запроса
    /// </summary>
    public TimeSpan CallTimeout { get; set; } = TimeSpan.FromSeconds(5);

    public override string ConfigBlockName => "Grpc";
}