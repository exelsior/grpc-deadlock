using Server.Settings;

namespace Server;

public static class SettingsExtensions
{
    public static T GetAndConfigureSettings<T>(
        this IServiceCollection services,
        IConfiguration configuration)
        where T : BaseSettings, new()
    {
        T instance = new T();
        IConfigurationSection section = configuration.GetSection(instance.ConfigBlockName);
        section.Bind((object) instance);
        services.Configure<T>((IConfiguration) section);
        return instance;
    }
}