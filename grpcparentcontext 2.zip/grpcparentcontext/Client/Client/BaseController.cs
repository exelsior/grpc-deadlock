using Microsoft.AspNetCore.Mvc;

namespace Client;

[Route("[controller]/[action]")]
public abstract class BaseController : Controller
{ 
    protected BaseController()
    {
    }
}